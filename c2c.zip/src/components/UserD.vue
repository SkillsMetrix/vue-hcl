<template>
    <div class="component">
   USer Details
   <p>User Name: {{ switchName() }} and age is : {{ userAge }}</p>
   <button @click="resetName">Reset Name</button>
    </div>
</template>

<script>
import { eventBus } from "../main";

export default{
    props:{
       name:{
        type:String
       },
       userAge: Number
    },
    methods: {
        switchName(){
            return this.name.split('').reverse().join('')
        },
        resetName(){
            this.name='Admin'
            this.$emit('namewasreset',this.name)
        }
    },
    created() {
        eventBus.$on('agewaschanged',(age)=>{
            this.userAge=age
        })
    },

}
</script>

<style scoped>
div{
    background-color: lightcoral;
}
</style>