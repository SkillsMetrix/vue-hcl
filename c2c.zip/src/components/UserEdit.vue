<template>
    <div class="component">
        UserAge is : {{ userAge }}
        <button @click="editAge">Change Age</button>
    </div>
 
</template>


<script>
import { eventBus } from "../main";
export default {
props :['userAge'],

methods:{
    editAge(){
        this.userAge=40
       // this.$emit('agewaschanged',this.userAge)
       eventBus.$emit('agewaschanged',this.userAge)

    }
}
}
</script>

<style scoped>
div{
    background-color: lightgreen;
}
</style>