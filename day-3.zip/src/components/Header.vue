<template>
<p>Header</p>
</template>

<script>
 
 export default {
    data: function () {
      return {
        status: "Normal Working",
      };
    },
 }
</script>