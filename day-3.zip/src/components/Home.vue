<template>
  <div>
    <ServerStat v-for="server in 5"></ServerStat>
    <Header></Header>
  </div>
 
</template>

<script>
 import ServerStat from './ServerStatus.vue'
 import Header from './Header.vue'

 export default {
  components:{
    ServerStat,
    Header
  }
 }
</script>
