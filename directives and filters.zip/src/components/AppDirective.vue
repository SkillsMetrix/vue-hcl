<template>
  <div>
    <p>Custom Directives</p>
    <h3 v-highlight:background.delayed="'red'">Color This</h3>
    <h3 v-local-directive:background.delayed.blink="'pink'">Color This</h3>
  </div>
</template>

<script>
export default {
  directives: {
    "local-directive": {
      bind(el, binding, vnode) {
        //el.style.backgroundColor='red'
        //el.style.backgroundColor=binding.value
        var delay = 0;
        if (binding.modifiers["delayed"]) {
          delay = 3000;
        }
        if (binding.modifiers["blink"]) {
          let mainColor = binding.value;
          let secondColor = "yellow";
          let currentColor = mainColor;
          setTimeout(() => {
            setInterval(() => {
              currentColor == secondColor
                ? (currentColor = mainColor)
                : (currentColor = secondColor);
            }, 1000);
            if (binding.arg == "backgroud") {
              el.style.backgroundColor = currentColor;
            } else {
              el.style.color = currentColor;
            }
          }, 1000);
        
        } else {
          setTimeout(() => {
            if (binding.arg == "background") {
              el.style.backgroundColor = binding.value;
            } else {
              el.style.color = binding.value;
            }
          }, delay);
        }
      },
    },
  },
};
</script>
