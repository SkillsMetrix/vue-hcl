<template>
  <div id="app">
  <Forms></Forms>
  </div>
</template>

<script>
import Forms from './components/Forms.vue';
export default {
  components:{
    Forms
  }
 
}
 
</script>

 
 