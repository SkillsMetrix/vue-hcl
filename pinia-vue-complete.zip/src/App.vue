<template>
  <div>
    <heading></heading>

    <hr>

    <div class="new-task-form">
      <tf></tf>
    </div>

    <hr />
    <p style="text-align: center">
      Welcome.<strong>{{ taskStore.name }}!</strong> for the Task Manager App
    </p>

    <hr />
    <nav class="filter">
   <button @click="filter='all'">All Tasks</button>
   <button @click="filter='favs'">Fav Tasks</button>
    </nav>

    <div class="task-list" v-if="filter === 'all'">
      <p>You have {{ taskStore.totalCount }} Task left to finish</p>
      <div v-for="task in taskStore.tasks">
         <tdetails :task="task"></tdetails>
        
      </div>
    </div>

    <div class="task-list">
      <p>You have {{ taskStore.favCount }} Task left to finish</p>
      <div v-for="task in taskStore.favs"  v-if="filter === 'favs'">
         <tdetails :task="task"></tdetails>
        
      </div>
    </div>


  </div>
</template>

<script>
import { ref } from "vue";
import Heading from "./components/Heading.vue";
import TaskDetails from "./components/TaskDetails.vue" 
import TaskForm from './components/TaskForm.vue'
import { useTaskStore } from "./stores/TaskStore";

export default {
  components: {
    heading: Heading,
    tdetails:TaskDetails,
    tf:TaskForm
  },
  setup() {
    const taskStore = useTaskStore();
    const filter= ref('all')
    return { taskStore,filter };
  },
};
</script>

<style scoped></style>
