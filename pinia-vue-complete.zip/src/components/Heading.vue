<template>
  <main>
    <header>
      <img src="https://pinia.vuejs.org/logo.svg" alt="" />
      <h1>Pinia App</h1>
    </header>
  </main>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped></style>
