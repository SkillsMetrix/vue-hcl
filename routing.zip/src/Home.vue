<template>
 <div>
    Home
    <hr>
     
 </div>
</template>

<script>
export default {
methods:{
   
}
}
</script>