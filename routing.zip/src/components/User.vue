<template>
    <div>
       User Component : {{ id }}
      
       <button @click="navigateToHome" class="btn btn-primary">Go To Home</button>
       <hr>
       <router-view></router-view>
    </div>
   </template>
   
   <script>
   export default {
    
   methods:{
      navigateToHome(){
         this.$router.push({name:'home'})
      }
   }
   }
   </script>