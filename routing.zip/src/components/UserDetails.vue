<template>
    <div>
        UserDetails component 
        <p>User Loaded with ID :{{ $route.params.id }}</p>
        <hr>
        <router-link class="btn btn-warning" :to="{name: 'userEdit',params:{id:$route.params.id},query:{locale:'en',q:100}}" tag="button"> Edit User</router-link>

    </div>
   
</template>