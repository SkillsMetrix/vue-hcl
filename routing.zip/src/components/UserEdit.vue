<template>
    <div>
        UserEdit component:
        <p>Locale :{{$route.query.locale}}</p>
        <p>Analytics :{{$route.query.q}}</p>
    </div>
   
</template>