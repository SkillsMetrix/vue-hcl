import User from './components/User.vue'
import Home from './Home.vue'
import UserDetails from './components/UserDetails.vue'
import UserEdit from './components/UserEdit.vue'
import UserStart from './components/UserStart.vue'
import Header from './Header.vue'
 
export const routes=[
    {path:'',name:'home', components:{
        default:Home,
        'header-top':Header
    }},

    {path:'/user',components:{
        default:User,
        'header-bottom':Header
    },children:[
        {path:'',component:UserStart},
        {path:':id',component:UserDetails},
        {path:':id/edit',component:UserEdit,name:'userEdit'}
    ]},
    {path:'/redirect-me',redirect:{name:'home'}}
]