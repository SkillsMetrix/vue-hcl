<template>
    <div class="component">
        <h3>You may view the User Details here</h3>
        <p>Many Details</p>
        <p>User Name: {{ switchName() }}</p>
        <p>User Age is  : {{ userAge }}</p>
        <button @click="resetName">Reset Name</button>
        <button @click="resetFN">Reset Name</button>
    </div>
</template>

<script>
 import eventBus from "./eventBus";
 import { ref, onMounted, onUnmounted } from "vue";

export default{
     
    props: {
        Myname:{
           type: String,
        
        },
        userAge: Number,
        resetFN : Function
    },
    methods:{
        switchName(){
            return this.Myname.split("").reverse().join("")
        },
        resetName(){
            this.Myname='ADMIN'
            emit('nameWasReset',this.Myname)
        }
    },
    onMounted(){
        eventBus.on('ageWasEdited',(age) =>{
            this.userAge=age
        })
    }
}
</script>

<style scoped>
    div {
        background-color: lightcoral;
    }
</style>


