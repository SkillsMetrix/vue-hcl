<script setup lang="ts">
import { ref, onMounted, onUnmounted } from "vue";
import eventBus from "../../src/components/eventBus";

const message = ref("");

const receiveMessage = (msg: string) => {
  message.value = msg;
};

onMounted(() => {
  eventBus.on("messageEvent", receiveMessage);
});

onUnmounted(() => {
  eventBus.off("messageEvent", receiveMessage);
});
</script>

<template>
  <div class="p-4 border rounded-md shadow-md">
    <h2 class="text-lg font-bold">Receiver Component</h2>
    <p v-if="message" class="mt-2 text-green-600 font-semibold">Received: {{ message }}</p>
  </div>
</template>
