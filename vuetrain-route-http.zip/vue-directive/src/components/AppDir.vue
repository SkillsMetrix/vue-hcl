<script setup lang="ts">
import { ref } from "vue";
 
const userColor = ref(""); // Store user input
</script>

<template>
  <div class="p-6 border rounded shadow">
    <h2 class="text-lg font-bold mb-2">Enter a Color</h2>

    <input
      v-input-color
      v-model="userColor"
      type="text"
      placeholder="Type a color (e.g., red, #ff5733)"
      class="border p-2 rounded w-full"
    />

    <p class="text-sm text-gray-500 mt-2">
      The text color of this input will change as you type a valid color name or hex code.
    </p>
  </div>
</template>
