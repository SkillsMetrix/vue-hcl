

<template>
<div>
    <p>This is filter demo</p>
    <h3>{{ text | toUppercase | to-lowercase }}</h3>
    <hr>
    <input placeholder="Serach users" v-model="filterText"/>
    <ul>
        <li v-for="user in filterUsers">{{ user }}</li>
    </ul>
    <hr>
    <app-list></app-list>
</div>
</template>


<script>
import List from './List.vue'
export default {
    data(){
        return{
            text:'welcome user',
            users:['suresh','reena','mahesh','preeti'],
            filterText:''

        }
    },
    filters:{
        toUppercase(value){
            return value.toUpperCase()
        }
    },
    computed:{
        filterUsers(){
            return this.users.filter((element)=> {
                return element.match(this.filterText)
            })
        }
    },
    components:{
        appList:List
    }
}
</script>