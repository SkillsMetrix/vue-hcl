

<template>
    <div>
        <p>This is filter demo</p>
    
        <hr>
        <input placeholder="Serach users" v-model="filterText"/>

        <button @click="users.push('arpit')">Add User</button>
        <ul>
            <li v-for="user in filterUsers">{{ user }}</li>
        </ul>
    </div>
    </template>
    
    
    <script>
    import {userMixin} from '../mixins/usersMixin'
    
    export default {
       mixins:[userMixin],
       created(){
        console.log('created inside list comp');
       }
    }
    </script>