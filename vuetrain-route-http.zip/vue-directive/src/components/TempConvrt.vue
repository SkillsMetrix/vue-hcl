<script setup lang="ts">
import { ref } from "vue";
 
const temperature = ref(""); // User input
</script>

<template>
  <div class="p-6 border rounded shadow">
    <h2 class="text-lg font-bold mb-2">Temperature Converter</h2>

    <input
      v-temp-convert
      v-model="temperature"
      type="text"
      placeholder="Enter Celsius (e.g., 25)"
      class="border p-2 rounded w-full"
    />

    <p class="text-sm text-gray-500 mt-2">
      Type a temperature in Celsius, and it will be converted to Fahrenheit automatically.
    </p>
  </div>
</template>
