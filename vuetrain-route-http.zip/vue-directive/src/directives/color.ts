import { Directive } from "vue";

const vColor: Directive = {
  mounted(el: HTMLElement, binding) {
    el.style.color = binding.value || "black"; // Default to black if no value is provided
  },
  updated(el: HTMLElement, binding) {
    el.style.color = binding.value || "black"; // Update color when value changes
  },
};

export default vColor;
