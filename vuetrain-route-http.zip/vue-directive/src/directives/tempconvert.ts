import { Directive } from "vue";

const vTempConvert: Directive = {
  mounted(el: HTMLInputElement) {
    el.addEventListener("input", () => {
      const celsius = parseFloat(el.value);
      if (!isNaN(celsius)) {
        const fahrenheit = (celsius * 9) / 5 + 32;
        el.value = `${fahrenheit.toFixed(2)} °F`; // Convert and update input
      } else {
        el.value = ""; // Clear if input is invalid
      }
    });
  },
  unmounted(el: HTMLInputElement) {
    el.removeEventListener("input", () => {});
  },
};

export default vTempConvert;
