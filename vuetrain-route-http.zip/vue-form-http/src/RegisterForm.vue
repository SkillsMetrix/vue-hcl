<script setup lang="ts">
import { ref } from "vue";
import axios from "axios";

// Define form data with TypeScript
interface User {
  name: string;
  email: string;
  password: string;
}

const form = ref<User>({
  name: "",
  email: "",
  password: "",
});

const message = ref(null);
const loading = ref(false);

const registerUser = async () => {
  message.value = null;
  loading.value = true;

  try {
    const response = await axios.post("http://localhost:3000/users", form.value);
    message.value = "Registration successful!";
    console.log("User registered:", response.data);
    form.value = { name: "", email: "", password: "" }; // Reset form
  } catch (error) {
    message.value = "Registration failed!";
    console.error(error);
  } finally {
    loading.value = false;
  }
};
</script>

<template>
  <div class="form-container">
    <h2>Register</h2>
    <form @submit.prevent="registerUser">
      <div>
        <label for="name">Name</label>
        <input id="name" v-model="form.name" required />
      </div>
      <div>
        <label for="email">Email</label>
        <input id="email" type="email" v-model="form.email" required />
      </div>
      <div>
        <label for="password">Password</label>
        <input id="password" type="password" v-model="form.password" required />
      </div>
      <button type="submit" :disabled="loading">
        {{ loading ? "Registering..." : "Register" }}
      </button>
    </form>
    <p v-if="message">{{ message }}</p>
  </div>
</template>

<style scoped>
.form-container {
  max-width: 400px;
  margin: auto;
  padding: 20px;
  border: 1px solid #ddd;
  border-radius: 5px;
}
label {
  display: block;
  margin-top: 10px;
}
input {
  width: 100%;
  padding: 8px;
  margin-top: 5px;
  border: 1px solid #ccc;
  border-radius: 4px;
}
button {
  margin-top: 15px;
  padding: 10px;
  width: 100%;
  background: blue;
  color: white;
  border: none;
  cursor: pointer;
}
</style>
