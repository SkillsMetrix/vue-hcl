<template>
  <div>
    <RegisterForm/>
    <UserDetails/>
   </div>
</template>

<script>
import RegisterForm from './RegisterForm.vue'
import UserDetails from './UserDetails.vue'
export default{
  components:{
    RegisterForm,
    UserDetails
  }
}
</script>