<script setup lang="ts">
import { ref, onMounted } from "vue";
import { getUsers, User } from  "@/services/userService";

const users = ref<User[]>([]);

const loadUsers = async () => {
  try {
    users.value = await getUsers();
  } catch (error) {
    console.error("Error fetching users:", error);
  }
};

onMounted(loadUsers);
</script>

<template>
  <div>
    <h2>All Users</h2>
    <ul v-if="users.length">
      <li v-for="user in users" :key="user.id">
        <strong>{{ user.name }}</strong> - {{ user.email }}
      </li>
    </ul>
    <p v-else>Loading users...</p>
  </div>
</template>
