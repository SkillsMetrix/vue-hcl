import axios from "axios";

const API_URL = "http://localhost:3000/users";

export interface User {
  name: string;
  email: string;
  password: string;
}

export const registerUser = async (user: User) => {
  return await axios.post(API_URL, user);
};

export const getUsers = async (): Promise<User[]> => {
  const response = await axios.get<User[]>(`${API_URL}`);
  return response.data;
};