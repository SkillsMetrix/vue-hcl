import axios from 'axios';

const API_URL = 'http://localhost:3000/students';

export interface Student {
  id?: number;
  name: string;
  age: number;
  course: string;
}

class StudentService {
  getAll() {
    return axios.get<Student[]>(API_URL);
  }

  getById(id: number) {
    return axios.get<Student>(`${API_URL}/${id}`);
  }

  create(student: Student) {
    return axios.post<Student>(API_URL, student);
  }

  update(id: number, student: Student) {
    return axios.put<Student>(`${API_URL}/${id}`, student);
  }

  delete(id: number) {
    return axios.delete(`${API_URL}/${id}`);
  }
}

export default new StudentService();
