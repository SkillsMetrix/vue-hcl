<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import StudentService, { Student } from '@/services/StudentService';

const student = ref<Student>({ name: '', age: 0, course: '' });
const route = useRoute();
const router = useRouter();
const isEditMode = ref(false);

onMounted(async () => {
  if (route.params.id) {
    isEditMode.value = true;
    const response = await StudentService.getById(Number(route.params.id));
    student.value = response.data;
  }
});

const saveStudent = async () => {
  if (isEditMode.value) {
    await StudentService.update(Number(route.params.id), student.value);
  } else {
    await StudentService.create(student.value);
  }
  router.push('/');
};
</script>

<template>
  <div class="container mt-4">
    <h2>{{ isEditMode ? 'Edit' : 'Add' }} Student</h2>
    <form @submit.prevent="saveStudent">
      <div class="mb-3">
        <label class="form-label">Name</label>
        <input v-model="student.name" type="text" class="form-control" required />
      </div>
      <div class="mb-3">
        <label class="form-label">Age</label>
        <input v-model="student.age" type="number" class="form-control" required />
      </div>
      <div class="mb-3">
        <label class="form-label">Course</label>
        <input v-model="student.course" type="text" class="form-control" required />
      </div>
      <button type="submit" class="btn btn-success">
        <i class="fas fa-save"></i> {{ isEditMode ? 'Update' : 'Save' }}
      </button>
    </form>
  </div>
</template>
