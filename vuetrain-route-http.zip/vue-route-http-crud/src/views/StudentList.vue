<script setup lang="ts">
import { ref, onMounted } from 'vue';
import StudentService, { Student } from '@/services/StudentService';

const students = ref<Student[]>([]);

const fetchStudents = async () => {
  try {
    const response = await StudentService.getAll();
    students.value = response.data;
  } catch (error) {
    console.error('Error fetching students:', error);
  }
};

const deleteStudent = async (id: number) => {
  if (confirm('Are you sure you want to delete this student?')) {
    await StudentService.delete(id);
    fetchStudents();
  }
};

onMounted(fetchStudents);
</script>

<template>
  <div class="container mt-4">
    <h2>Student List</h2>
    <router-link to="/add" class="btn btn-primary mb-3">
      <i class="fas fa-plus"></i> Add Student
    </router-link>
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Age</th>
          <th>Course</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="student in students" :key="student.id">
          <td>{{ student.id }}</td>
          <td>{{ student.name }}</td>
          <td>{{ student.age }}</td>
          <td>{{ student.course }}</td>
          <td>
            <router-link :to="'/edit/' + student.id" class="btn btn-warning btn-sm me-2">
              <i class="fas fa-edit"></i> Edit
            </router-link>
            <button @click="deleteStudent(student.id!)" class="btn btn-danger btn-sm">
              <i class="fas fa-trash"></i> Delete
            </button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
