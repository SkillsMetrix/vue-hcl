import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router';
import HomeView from '@/views/HomeView.vue';
import NotFound from '@/views/NotFound.vue';

// Lazy-loaded routes
const AboutView = () => import('@/views/AboutView.vue');
const UserProfile = () => import('@/views/UserProfile.vue');

// Define routes with type safety
const routes = [
  { path: '/', name: 'Home', component: HomeView },
  { path: '/about', name: 'About', component: AboutView },
  
  // Dynamic route with parameter
  { path: '/user/:id', name: 'UserProfile', component: UserProfile, props: true },
  
  // Redirect example
  { path: '/old-route', redirect: '/about' },
  
  // Catch-all 404 route
  { path: '/:pathMatch(.*)*', name: 'NotFound', component: NotFound }
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

// Global navigation guard
router.beforeEach((to, from, next) => {
  console.log(`Navigating from ${from.fullPath} to ${to.fullPath}`);
  next();
});

export default router;
