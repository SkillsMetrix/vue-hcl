<template>
    <div>
      <h1>Home Page</h1>
      <router-link to="/about">Go to About</router-link>
    </div>
  </template>
  