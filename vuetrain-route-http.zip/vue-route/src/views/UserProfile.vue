<script setup lang="ts">
import { defineProps } from 'vue';

defineProps<{ id: string }>();
</script>

<template>
  <div>
    <h1>User Profile</h1>
    <p>User ID: {{ id }}</p>
    <router-link to="/">Back to Home</router-link>
  </div>
</template>
