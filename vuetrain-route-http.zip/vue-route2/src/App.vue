<template>
  <nav>
    <router-link to="/">Home</router-link> |
    <router-link to="/dashboard">Dashboard</router-link> |
    <router-link to="/profile">Profile</router-link> |
    <router-link to="/admin">Admin</router-link>
  </nav>
  <router-view />
</template>
