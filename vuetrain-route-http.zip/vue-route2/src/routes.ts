import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router';
import HomeView from '@/views/HomeView.vue';
import DashboardView from '@/views/DashboardView.vue';
import LoginView from '@/views/LoginView.vue';
import NotFoundView from '@/views/NotFoundView.vue';
import UserLayout from '@/views/UserLayout.vue';
import UserProfile from '@/views/UserProfile.vue';
import UserSettings from '@/views/UserSettings.vue';

const isAuthenticated = () => {
  return localStorage.getItem('auth') === 'true'; // Mock auth check
};

// Global guard
const authGuard = (to: any, from: any, next: any) => {
  if (isAuthenticated()) {
    next();
  } else {
    next('/login');
  }
};

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    name: 'Home',
    component: HomeView,
  },
  {
    path: '/dashboard',
    name: 'Dashboard',
    component: DashboardView,
    beforeEnter: authGuard, // Route Guard
  },
  {
    path: '/login',
    name: 'Login',
    component: LoginView,
  },
  {
    path: '/user',
    component: UserLayout,
    beforeEnter: authGuard, // Protect all nested routes
    children: [
      {
        path: '',
        redirect: '/user/profile',
      },
      {
        path: 'profile',
        name: 'UserProfile',
        component: UserProfile,
      },
      {
        path: 'settings',
        name: 'UserSettings',
        component: UserSettings,
      },
    ],
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: NotFoundView,
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
