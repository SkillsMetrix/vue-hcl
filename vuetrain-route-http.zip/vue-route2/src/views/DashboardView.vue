<template>
    <div>
      <h1>Dashboard</h1>
      <router-link to="/user">User Section</router-link>
    </div>
  </template>
  