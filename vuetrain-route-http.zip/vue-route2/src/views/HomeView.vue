<template>
    <div>
      <h1>Home</h1>
      <router-link to="/dashboard">Go to Dashboard</router-link>
    </div>
  </template>
  