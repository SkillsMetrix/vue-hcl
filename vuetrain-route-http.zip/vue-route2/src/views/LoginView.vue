<template>
    <div>
      <h1>Login</h1>
      <button @click="login">Login</button>
    </div>
  </template>
  
  <script setup lang="ts">
  import { useRouter } from 'vue-router';
  
  const router = useRouter();
  
  const login = () => {
    localStorage.setItem('auth', 'true');
    router.push('/dashboard');
  };
  </script>
  