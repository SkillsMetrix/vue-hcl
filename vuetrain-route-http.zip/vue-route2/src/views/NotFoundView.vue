<template>
    <div>
      <h1>404 - Not Found</h1>
      <router-link to="/">Go Home</router-link>
    </div>
  </template>
  