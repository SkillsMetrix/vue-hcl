<template>
    <div>
      <h2>User Section</h2>
      <nav>
        <router-link to="/user/profile">Profile</router-link>
        <router-link to="/user/settings">Settings</router-link>
        <button @click="logout">Logout</button>
      </nav>
      <router-view></router-view>
    </div>
  </template>
  
  <script setup lang="ts">
  import { useRouter } from 'vue-router';
  
  const router = useRouter();
  
  const logout = () => {
    localStorage.removeItem('auth');
    router.push('/login');
  };
  </script>
  