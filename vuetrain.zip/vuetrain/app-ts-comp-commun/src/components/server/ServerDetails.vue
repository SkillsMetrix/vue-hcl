<template>
  <div>
    <p>Server details are currently not updated</p>
  </div>
    </template>
    
    <script>
     
   
    </script>


<style scoped>
div{
    border: 1px solid red;
}
</style>