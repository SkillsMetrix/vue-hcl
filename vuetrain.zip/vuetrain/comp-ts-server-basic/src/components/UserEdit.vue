<template>
    <div class="component">
        <h3>You may edit the User here</h3>
        <p>Edit me! {{ userAge }}</p>
        <button @click="editAge">Edit Age</button>
    </div>
</template>

<script>
 import eventBus from "./eventBus";

 export default {
    props:['userAge'],
methods: {
    editAge(){
        this.userAge=32
       
        eventBus.emit('ageWasEdited',this.userAge)
    }
}
}
</script>

<style scoped>
    div {
        background-color: lightgreen;
    }
</style>
