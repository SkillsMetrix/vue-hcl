<script setup lang="ts">
import eventBus from "../../src/components/eventBus";

const sendMessage = () => {
  eventBus.emit("messageEvent", "Hello from Sender!");
};
</script>

<template>
  <div class="p-4 border rounded-md shadow-md">
    <h2 class="text-lg font-bold">Sender Component</h2>
    <button @click="sendMessage" class="px-4 py-2 bg-blue-500 text-white rounded">
      Send Message
    </button>
  </div>
</template>
