export default interface ResponseData {
  data: any;
}