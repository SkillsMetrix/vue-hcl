<script setup lang="ts">
import { ref } from "vue";
//import vColor from "@/directives/color";

const color = ref("blue"); // Default color

const changeColor = () => {
  color.value = color.value === "blue" ? "red" : "blue"; // Toggle color
};
</script>

<template>
  <div class="p-6 border rounded shadow">
    <h2 v-color="color" class="text-lg font-bold">
      This text changes color!
    </h2>
    <button @click="changeColor" class="mt-4 px-4 py-2 bg-gray-500 text-white rounded">
      Change Color
    </button>
  </div>
</template>
