import { Directive } from "vue";

const vInputColor: Directive = {
  mounted(el: HTMLInputElement) {
    el.addEventListener("input", () => {
      el.style.color = el.value || "black"; // Set input text color
    });
  },
  unmounted(el: HTMLInputElement) {
    el.removeEventListener("input", () => {
      el.style.color = el.value || "black";
    });
  },
};

export default vInputColor;
