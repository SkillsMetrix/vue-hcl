 
import { createApp } from 'vue'
import App from './App.vue'
import vInputColor from './directives/textcolor'
 import vTempConvert from './directives/tempconvert'
import vColor from './directives/color'

const app=createApp(App)
app.directive("color", vColor);
app.directive("input-color", vInputColor);
app.directive("temp-convert", vTempConvert);

app.mount('#app')
