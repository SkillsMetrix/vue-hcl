


export const userMixin={
    data(){
        return{
            
            users:['suresh','reena','mahesh','preeti'],
            filterText:''

        }
    },
 
    computed:{
        filterUsers(){
            return this.users.filter((element)=> {
                return element.match(this.filterText)
            })
        }
    },
    created() {
        console.log('created');
    },
}
