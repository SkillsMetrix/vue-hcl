import { createRouter, createWebHistory } from 'vue-router';
import Register from '@/views/Register.vue';
import Users from '@/views/Users.vue';

const routes = [
  { path: '/', component: Register },
  { path: '/users', component: Users },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
