import axios from 'axios';

const API_URL = 'http://localhost:3000/users';

export interface User {
  id?: number;
  name: string;
  email: string;
  password: string;
}

export const getUsers = () => axios.get<User[]>(API_URL);
export const registerUser = (user: User) => axios.post(API_URL, user);
