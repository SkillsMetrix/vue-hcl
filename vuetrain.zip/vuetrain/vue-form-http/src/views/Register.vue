<script setup lang="ts">
import { ref } from 'vue';
import { registerUser } from '@/services/api';
import { useRouter } from 'vue-router';

const router = useRouter();

const name = ref('');
const email = ref('');
const password = ref('');
const message = ref('');

const register = async () => {
  if (!name.value || !email.value || !password.value) {
    message.value = 'All fields are required!';
    return;
  }

  try {
    await registerUser({ name: name.value, email: email.value, password: password.value });
    message.value = 'User registered successfully!';
    setTimeout(() => router.push('/users'), 1000);
  } catch (error) {
    message.value = 'Registration failed!';
  }
};
</script>

<template>
  <div>
    <h1>Register</h1>
    <input v-model="name" placeholder="Name" />
    <input v-model="email" placeholder="Email" type="email" />
    <input v-model="password" placeholder="Password" type="password" />
    <button @click="register">Register</button>
    <p>{{ message }}</p>
  </div>
</template>
