<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { getUsers, User } from '@/services/api';

const users = ref<User[]>([]);

const fetchUsers = async () => {
  const { data } = await getUsers();
  users.value = data;
};

onMounted(fetchUsers);
</script>

<template>
  <div>
    <h1>Registered Users</h1>
    <router-link to="/">Register New User</router-link>
    <ul>
      <li v-for="user in users" :key="user.id">
        <strong>{{ user.name }}</strong> ({{ user.email }})
      </li>
    </ul>
  </div>
</template>
