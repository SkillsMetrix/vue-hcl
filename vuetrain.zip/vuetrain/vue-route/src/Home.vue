<template>
 <div>
     
    <hr>
     
 </div>
</template>

<script>
import Header from './Header.vue'
export default {


methods:{
   
}
}
</script>