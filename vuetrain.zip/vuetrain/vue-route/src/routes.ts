import Home from './Home.vue';
import Header from './Header.vue';
import { createRouter, createWebHistory } from "vue-router";

 
/* const User = resolve => {
    require.ensure(['./components/User.vue'], () => {
        resolve(require('./components/User.vue'));
    }, 'user');
};
const UserStart = resolve => {
    require.ensure(['./components/UserStart.vue'], () => {
        resolve(require('./components/UserStart.vue'));
    }, 'user');
};
const UserEdit = resolve => {
    require.ensure(['./components/UserEdit.vue'], () => {
        resolve(require('./components/UserEdit.vue'));
    }, 'user');
};
const UserDetail = resolve => {
    require.ensure(['./components/UserDetails.vue'], () => {
        resolve(require('./components/UserDetails.vue'));
    }, 'user');
}; */

const routes = [
    {
        path: '', name: 'home', components: Home
     
    },
    
   
];

const router = createRouter({
    history: createWebHistory(),
    routes,
  });
  
  export default router;