<template>
  <div id="app" class="container">
    <div class="row">
    <Counter></Counter>
    <hr>
    <Result></Result>
<hr>
    <AnotherResult></AnotherResult>
    <hr>
    <AnotherCounter></AnotherCounter>
  </div>

  <hr>
  <input type="text" v-model="value"  />
  {{ value }}
</div>
</template>

<script>
import Counter from './components/Counter.vue'
import AnotherCounter from './components/AnotherCounter.vue'
import Result from './components/Result.vue'
import AnotherResult from './components/AnotherResult.vue'
export default {

  name: 'app',
  computed:{
    value:{
      get(){
        return this.$store.getters.value
      },
      set(value){
        this.$store.dispatch('updateValue',value)
      }
      
    }
  },
  methods:{
    updateValue(event) {
      this.$store.dispatch('updateValue',event.target.value)
    }
  },
  components:{
Counter,
Result,
AnotherResult,
AnotherCounter
  }
}
</script>

