<template>
    <div>
      <div>
        <button class="btn btn-primary" @click="increment">Increment</button>
        <button class="btn btn-danger" @click="decrement">Decrement</button>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    methods: {
      increment() {
        this.$store.state.counter++
      },
      decrement() {
          this.$store.state.counter--
      },
    },
  };
  </script>
  