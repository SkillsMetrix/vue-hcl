<template>
  <div>
  <div>Result of count is :{{ doubleCounter }}</div>
  <p>number of clicks :{{ stringCounter }}</p>

</div>
</template>

<script>
  import {mapGetters} from 'vuex'

export default {

computed:mapGetters([
'doubleCounter','stringCounter'
])

  
};
</script>
