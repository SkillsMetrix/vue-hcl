<template>
  <div>Result of count is :{{ counter }}</div>
</template>

<script>
export default {
  computed: {
    counter() {
      return this.$store.getters.doubleCounter
    },
  },
};
</script>
