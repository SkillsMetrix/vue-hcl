

export const  updateValue=(state,payload) =>{
    state.value=payload
}