<template>
  <div
    v-show="bannerMessage"
    v-bind:style="{ 'background-color': bannerBackgroundColor }"
  >
    <p>{{ bannerMessage }} --{{ bannerType }}</p>
  </div>
</template>

<script>
export default {
  props: {
    bannerMessage: String,
    bannerType: String,
  },
  computed: {
    bannerBackgroundColor() {
      if (this.bannerType === "Error") {
        return "red";
      } else if (this.bannerType === "Success") {
        return "green";
      } else {
        return "blue";
      }
    },
  },
};
</script>

<style scoped>
div {
  width: 100%;
  display: inline-block;
  margin-bottom: 15px;
}
span p {
  padding: 15px;
  color: white;
  width: auto;
}
</style>
