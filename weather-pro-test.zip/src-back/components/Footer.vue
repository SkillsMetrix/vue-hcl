<template>
  <footer>
    <h1>{{ fm }}</h1>
  </footer>
</template>

<script>
export default {
  props: {
    fm: String,
  },
};
</script>

<style scoped>
footer {
  margin: auto;
}
</style>
