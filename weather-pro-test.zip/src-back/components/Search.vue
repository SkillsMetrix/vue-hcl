<template>
  <div>
    Search:<input
      type="text"
      placeholder="Search city here"
      v-model="inputCity"
    />
    <button @click="searchCity">Load</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      inputCity: "",
    };
  },
  methods: {
    searchCity() {
      this.$emit("search-city", this.inputCity);
    },
  },
};
</script>
