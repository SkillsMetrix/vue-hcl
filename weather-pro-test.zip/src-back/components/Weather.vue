<template>
    <div>
        Weather Data
        <div>
            <h4>{{ city }}</h4>
            <h4>{{ weatherSummary }}</h4>
            <h4>{{ weatherDescription }}</h4>

        </div>
    </div>
</template>

<script>
export default{
    props:{
        city:String,
        weatherSummary:String,
        weatherDescription:String

    }
}
</script>